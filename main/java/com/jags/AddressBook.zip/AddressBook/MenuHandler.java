package com.jags.AddressBook;

/**
 * Created by jparvathaneni on 12/20/15.
 */
public interface MenuHandler {
    public int printMenuAndReadChoice();
}
